
class Algorithm:
    def getId(self):
        return
    def predict(self, datapoints):
        return
    def configure(self, configuration):
        return
    def train(self):
        return
    def getEvaluationStatus(self):
        return
    def getLabel(self):
        return
    def getConfiguration(self):
        return
